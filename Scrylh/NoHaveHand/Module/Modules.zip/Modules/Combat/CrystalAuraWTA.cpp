#include "CrystalAuraWTA.h"
#include <cmath>
#include <vector>
#include <algorithm>// For math functions like abs()

CrystalAuraWTA::CrystalAuraWTA() : IModule(0x0, Category::COMBAT, "CrystalAura by Tony UWU") {
	registerIntSetting("range", &range, range, 1, 10);
	registerBoolSetting("autoplace", &autoplace, autoplace);
	//registerBoolSetting("onlyCrystal", &crystalCheck, crystalCheck);
	//registerBoolSetting("LockY", &yLock, yLock);
	registerIntSetting("delay", &delay, delay, 0, 20);
	registerBoolSetting("onClick", &isClick, isClick);
	//	registerBoolSetting("Multi", &doMultiple, doMultiple);
	
}
int crystalDelay = 0;
int crystalDelay2 = 0;
int crystalDelay3 = 0;

CrystalAuraWTA::~CrystalAuraWTA() {
}

const char* CrystalAuraWTA::getModuleName() {
	return ("CrystalAuraMIX");
}
static std::vector<C_Entity*> targetList7;

struct CompareTargetEnArray {
	bool operator()(C_Entity* lhs, C_Entity* rhs) {
		C_LocalPlayer* localPlayer = g_Data.getLocalPlayer();
		return (*lhs->getPos()).dist(*localPlayer->getPos()) < (*rhs->getPos()).dist(*localPlayer->getPos());
	}
};

void findEntity3(C_Entity* currentEntity, bool isRegularEntity) {
	static auto CrystalAuraWTAMod = moduleMgr->getModule<CrystalAuraWTA>();

	if (currentEntity == nullptr)
		return;

	if (currentEntity->getNameTag()->getTextLength() <= 1 && currentEntity->getEntityTypeId() == 71)  // crystal
		return;

	if (currentEntity == g_Data.getLocalPlayer())  // Skip Local player
		return;

	//if (!g_Data.getLocalPlayer()->canAttack(currentEntity, false))
	//return;

	if (!g_Data.getLocalPlayer()->isAlive())
		return;

	if (!currentEntity->isAlive())
		return;

	if (currentEntity->getNameTag()->getTextLength() <= 1 && currentEntity->getEntityTypeId() == 319)
		return;
	if (currentEntity->width <= 0.01f || currentEntity->height <= 0.01f)  // Don't hit this pesky antibot on 2b2e.org
		return;
	if (currentEntity->getEntityTypeId() == 64)  // item
		return;
	if (currentEntity->getEntityTypeId() == 69)  // xp_orb
		return;
	if (currentEntity->getEntityTypeId() == 80)  // arrow
		return;

	if (!TargetUtil::isValidTarget(currentEntity))
		return;

	//how hard is it to play fair? add back the badman check if its hard

	float dist = (*currentEntity->getPos()).dist(*g_Data.getLocalPlayer()->getPos());

	if (dist < CrystalAuraWTAMod->range) {
		targetList7.push_back(currentEntity);
		sort(targetList7.begin(), targetList7.end(), CompareTargetEnArray());
	}
}

bool checkTargCollision(vec3_t* block, C_Entity* ent) {
	vec3_t entPos = ent->getPos()->floor();
	entPos.y -= 1;
	std::vector<vec3_t*> corners;
	corners.clear();

	if (block->x >= entPos.x && block->x <= entPos.x + 1 &&
		block->y >= entPos.y && block->y <= entPos.y + 1 &&
		block->z >= entPos.z && block->z <= entPos.z + 1) {
		return true; // Collision detected
	}
	corners.push_back(new vec3_t(ent->aabb.lower.x, ent->aabb.lower.y, ent->aabb.lower.z));
	corners.push_back(new vec3_t(ent->aabb.lower.x, ent->aabb.lower.y, ent->aabb.upper.z));
	corners.push_back(new vec3_t(ent->aabb.upper.x, ent->aabb.lower.y, ent->aabb.upper.z));
	corners.push_back(new vec3_t(ent->aabb.upper.x, ent->aabb.lower.y, ent->aabb.lower.z));

	// Calculate a priority score for each corner based on proximity
	std::vector<std::pair<vec3_t*, float>> cornerScores;
	for (auto corner : corners) {
		float distance = corner->distanceTo(*block);
		cornerScores.push_back(std::pair<vec3_t*, float>(corner, distance));
	}

	// Sort the corner scores in ascending order
	std::sort(cornerScores.begin(), cornerScores.end(),
		[](const auto& a, const auto& b) { return a.second < b.second; });

	for (auto scorePair : cornerScores) {
		auto corner = scorePair.first;

		if ((floor(corner->x) == floor(block->x)) && (floor(corner->y) == floor(block->y)) && (floor(corner->z) == floor(block->z))) {
			return true;
		}
	}

	return false; // No collision
}

bool checkSurrounded2(C_Entity* ent) {
	vec3_t entPos = ent->getPos()->floor();
	entPos.y -= 1;
	std::vector<vec3_ti*> blockChecks;
	blockChecks.clear();

	// Add positions for all four directions
	blockChecks.push_back(new vec3_ti(entPos.x, entPos.y, entPos.z + 1));
	blockChecks.push_back(new vec3_ti(entPos.x, entPos.y, entPos.z - 1));
	blockChecks.push_back(new vec3_ti(entPos.x + 1, entPos.y, entPos.z));
	blockChecks.push_back(new vec3_ti(entPos.x - 1, entPos.y, entPos.z));

	bool isPlusXBlock = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x + 1, entPos.y, entPos.z))->toLegacy()->blockId != 0;
	bool isMinusXBlock = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x - 1, entPos.y, entPos.z))->toLegacy()->blockId != 0;
	bool isPlusZBlock = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z + 1))->toLegacy()->blockId != 0;
	bool isMinusZBlock = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z - 1))->toLegacy()->blockId != 0;

	bool isBlockedPlusX = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x + 2, entPos.y, entPos.z))->toLegacy()->blockId != 0;
	bool isBlockedMinusX = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x - 2, entPos.y, entPos.z))->toLegacy()->blockId != 0;
	bool isBlockedPlusZ = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z + 2))->toLegacy()->blockId != 0;
	bool isBlockedMinusZ = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z - 2))->toLegacy()->blockId != 0;

	if ((isPlusXBlock && isBlockedPlusX) || (isMinusXBlock && isBlockedMinusX) ||
		(isPlusZBlock && isBlockedPlusZ) || (isMinusZBlock && isBlockedMinusZ)) {
		return false; // Not surrounded
	}
	else {
		// Calculate a priority score for each block check based on proximity
		std::vector<std::pair<vec3_ti*, float>> blockCheckScores;
		for (auto blocks : blockChecks) {
			blockCheckScores.push_back(std::pair<vec3_ti*, float>(blocks, entPos.distanceTo(vec3_t(blocks->x, blocks->y, blocks->z))));
		}

		// Sort the block check scores in ascending order
		std::sort(blockCheckScores.begin(), blockCheckScores.end(),
			[](const auto& a, const auto& b) { return a.second < b.second; });

		for (auto scorePair : blockCheckScores) {
			auto blocks = scorePair.first;

			if (!checkTargCollision(&blocks->toVector3(), ent)) {
				return false;
			}
		}

		return true; // Surrounded
	}
}




std::vector<vec3_t*> getGucciPlacement2(C_Entity* ent) {
	vec3_t entPos = ent->getPos()->floor();
	entPos.y -= 1;
	std::vector<vec3_t*> finalBlocks;
	std::vector<vec3_ti*> blockChecks;
	blockChecks.clear();
	finalBlocks.clear();

	// Add positions for all four directions
	blockChecks.push_back(new vec3_ti(entPos.x, entPos.y, entPos.z + 1)); // North
	blockChecks.push_back(new vec3_ti(entPos.x, entPos.y, entPos.z - 1)); // South
	blockChecks.push_back(new vec3_ti(entPos.x + 1, entPos.y, entPos.z)); // East
	blockChecks.push_back(new vec3_ti(entPos.x - 1, entPos.y, entPos.z)); // West

	// Check for open positions on all four sides first
	for (auto blocks : blockChecks) {
		auto blkID = g_Data.getLocalPlayer()->region->getBlock(*blocks)->toLegacy()->blockId;
		if (blkID == 0 && !checkTargCollision(&blocks->toVector3(), ent)) {
			finalBlocks.push_back(new vec3_t(blocks->x, blocks->y, blocks->z));
		}
	}

	// Check for central position
	auto centralBlock = new vec3_ti(entPos.x, entPos.y, entPos.z);
	auto centralBlkID = g_Data.getLocalPlayer()->region->getBlock(*centralBlock)->toLegacy()->blockId;
	if (centralBlkID == 0 && !checkTargCollision(&centralBlock->toVector3(), ent)) {
		finalBlocks.push_back(new vec3_t(centralBlock->x, centralBlock->y, centralBlock->z));
	}

	// Check for anvil blocks on specific sides
	bool isPlusXAnvil = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x + 1, entPos.y, entPos.z))->toLegacy()->blockId == 145;
	bool isMinusXAnvil = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x - 1, entPos.y, entPos.z))->toLegacy()->blockId == 145;
	bool isPlusZAnvil = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z + 1))->toLegacy()->blockId == 145;
	bool isMinusZAnvil = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z - 1))->toLegacy()->blockId == 145;

	if (isPlusXAnvil) {
		finalBlocks.push_back(new vec3_t(entPos.x + 2, entPos.y, entPos.z));
	}
	if (isMinusXAnvil) {
		finalBlocks.push_back(new vec3_t(entPos.x - 2, entPos.y, entPos.z));
	}
	if (isPlusZAnvil) {
		finalBlocks.push_back(new vec3_t(entPos.x, entPos.y, entPos.z + 2));
	}
	if (isMinusZAnvil) {
		finalBlocks.push_back(new vec3_t(entPos.x, entPos.y, entPos.z - 2));
	}

	// Remove positions with collisions
	finalBlocks.erase(std::remove_if(finalBlocks.begin(), finalBlocks.end(),
		[&](vec3_t* pos) { return checkTargCollision(pos, ent); }),
		finalBlocks.end());

	return finalBlocks;
}




bool hasPlaced = false;
void CrystalAuraWTA::onEnable() {
	crystalDelay = 0;
	hasPlaced = false;
}
vec3_t espPosLower;
vec3_t espPosUpper;
vec3_t crystalPos;
std::vector<vec3_t*> placeArr;
//std::vector<vec3_t*> hitArr;

void findCr() {
	C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
	C_Inventory* inv = supplies->inventory;
	for (int n = 0; n < 9; n++) {
		C_ItemStack* stack = inv->getItemStack(n);
		if (stack->item != nullptr) {
			if (stack->getItem()->itemId == 637) {  // select crystal
				supplies->selectedHotbarSlot = n;
				//return true;
				return;
			}
		}
	}
	//return false;
}
void CrystalAuraWTA::onTick(C_GameMode* gm) {
	{
		if (g_Data.getLocalPlayer() == nullptr) return;
		if (isClick && !g_Data.isRightClickDown()) return;

		//	if (g_Data.getLocalPlayer()->getSelectedItemId() == 259) return;

		targetList7.clear();

		g_Data.forEachEntity(findEntity3);
		//hitArr.clear();
		//placeArr.clear();

		if (autoplace)
			if ((crystalDelay >= this->delay) && !(targetList7.empty())) {
				crystalDelay = 0;
				if (!checkSurrounded2(targetList7[0])) {
					auto supplies = g_Data.getLocalPlayer()->getSupplies();
					auto inv = supplies->inventory;
					slotCA = supplies->selectedHotbarSlot;
					C_ItemStack* item = supplies->inventory->getItemStack(0);
					findCr();
					std::vector<vec3_t*> gucciPositions = getGucciPlacement2(targetList7[0]);

					

					//615 = normal id for crystal || 616 = crystal id for nukkit servers
					if (!gucciPositions.empty()) {
						
						
						if (g_Data.getLocalPlayer()->getSelectedItemId() == 637) {
							placeArr.clear();
							for (auto place : gucciPositions) {
								//								if (hasPlaced && !doMultiple) break;
								if (targetList7.empty()) return;
								gm->buildBlock(&vec3_ti(place->x, place->y - 1, place->z), 2);
								//gm->buildBlock(&vec3_ti(place->x, place->y, place->z), 2);
								//gm->buildBlock(&vec3_ti(place->x, place->y + 1, place->z), 2);
								placeArr.push_back(new vec3_t(place->x, place->y - 1, place->z));
								hasPlaced = true;
							}
							g_Data.forEachEntity([](C_Entity* ent, bool b) {
								int id = ent->getEntityTypeId();

								if (id == 71 && g_Data.getLocalPlayer()->getPos()->dist(*ent->getPos()) <= 6) {
									
									
									g_Data.getCGameMode()->attack(ent);

								}

								});
						}
						
					} supplies->selectedHotbarSlot = slotCA;

					gucciPositions.clear();
				}
			}
			else if (!targetList7.empty()) {
				crystalDelay++;
			}

		//if (crystalDelay2 >= 20) {
		//		hasPlaced = false;
		//}

		  //*/
	}
}

void CrystalAuraWTA::onDisable() {
	crystalDelay = 0;
	hasPlaced = false;
}
/*
*
* //this right here is stuff i was working on but havent been bothered to finish*/

//*/
void CrystalAuraWTA::onPreRender(C_MinecraftUIRenderContext* renderCtx) {
	if (renderCA) {
		auto interfacrColor = ColorUtil::interfaceColor(1);
		C_LocalPlayer* localPlayer = g_Data.getLocalPlayer();
		if (localPlayer != nullptr && GameData::canUseMoveKeys()) {
			if (!targetList7.empty()) {
				if (!placeArr.empty()) {
					for (auto postt : placeArr) {
						//DrawUtils::drawwtf(*postt, 0.5f);
						DrawUtils::setColor(interfacrColor.r, interfacrColor.g, interfacrColor.b, 1.f);
						
						DrawUtils::drawBox(postt->floor().add(0.f, 0.999f, 0.f), vec3_t(floor(postt->x) + 1.f, floor(postt->y) + 1.f, floor(postt->z) + 1.f), 0.5f, true);
						
						
					} placeArr.clear();
				}
			}
			
			/*
			if (!hitArr.empty()) {
				for (auto postt : hitArr) {
					DrawUtils::setColor(interfacrColor.r, interfacrColor.g, interfacrColor.b, 1.f);
					DrawUtils::drawBox(postt->floor(), vec3_t(floor(postt->x) + 1.f, floor(postt->y) + 1.f, floor(postt->z) + 1.f), 0.5f, true);
				}
			}  //*/
		}
	}

}
